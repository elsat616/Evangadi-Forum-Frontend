import React from "react";
import Layout from "../../component/Layout/Layout";

function NotFound() {
  return (
    <Layout>
      <div style={{ textAlign: "center" }} className="container">
        <br />
        <br />
        <br />
        <br />
        <h1>Oops! Page Not Found!</h1>
        <br />
        <br />
        <br />
        <br />
      </div>
    </Layout>
  );
}

export default NotFound;
